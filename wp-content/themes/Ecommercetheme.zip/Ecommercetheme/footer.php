	<footer class="site-footer">
		
		
		
		<p><?php bloginfo('name'); ?> - &copy; <?php echo date('Y');?></p>
	
	</footer>


<?php wp_footer(); ?>
</body>
</html>